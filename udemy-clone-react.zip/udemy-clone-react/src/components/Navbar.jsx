export default function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar__s1">
        <h1 className="navbar__s1__title">Udemy</h1>
      </div>

      <div className="navbar__s2">
        <i className="fa-solid fa-magnifying-glass"></i>
        <input type="text" placeholder="Search for anything: Art, Tech, Design..." />
      </div>

      <div className="navbar__s3">
        <p>Courses</p>

        <div className="mylearning">
          <p>My Learning</p>
          <div className="mylearning__popup">
            <p>You did not complete any courses yet.</p>
          </div>
        </div>

        <i className="fa-solid fa-cart-shopping"></i>
        <i className="fa-solid fa-bell"></i>
        <i className="fa-solid fa-user"></i>
      </div>
    </header>
  );
}

export default function CourseCard({ course }) {
  const { img, alt, title, instructor, rating, ratingsCount, price, oldPrice } = course;

  return (
    <div className="course-card">
      <img src={img} alt={alt} loading="lazy" />
      <h3>{title}</h3>
      <p>{instructor}</p>
      <p>⭐ {rating} ({ratingsCount.toLocaleString()} Ratings)</p>
      <p>
        ${price.toFixed(2)} <del>${oldPrice.toFixed(2)}</del>
      </p>
    </div>
  );
}

import CourseCard from "./CourseCard.jsx";
import { recommendedCourses } from "../data/courses.js";

export default function Recommended() {
  return (
    <section className="recommended">
      <h2>Recommended for You</h2>
      <p>Pick the best fit.</p>

      <div className="recommended-container">
        {recommendedCourses.map((course) => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>
    </section>
  );
}

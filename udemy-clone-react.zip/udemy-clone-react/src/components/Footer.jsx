export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer_one">
        <div className="footer_one_s1">
          <p>Udemy Business</p>
          <p>Teach on Udemy</p>
          <p>Get the App</p>
          <p>About Us</p>
          <p>Contact Us</p>
        </div>

        <div className="footer_one_s2">
          <p>Careers</p>
          <p>Blog</p>
          <p>Help & Support</p>
          <p>Affiliate</p>
          <p>Investors</p>
        </div>
      </div>

      <div className="footer_two">
        <h2>Udemy Clone</h2>
        <p>&copy; 2026 Udemy, Inc.</p>
      </div>
    </footer>
  );
}

import { categories } from "../data/courses.js";

export default function Categories() {
  return (
    <nav className="categories">
      {categories.map((category) => (
        <p key={category}>{category}</p>
      ))}
    </nav>
  );
}

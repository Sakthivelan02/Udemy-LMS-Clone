import CourseCard from "./CourseCard.jsx";
import { popularCourses } from "../data/courses.js";

export default function Popular() {
  return (
    <section className="popular">
      <h2 className="popular_title">Popular Courses</h2>
      <p>Pick the best fit.</p>

      <div className="popular_container">
        {popularCourses.map((course) => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>
    </section>
  );
}

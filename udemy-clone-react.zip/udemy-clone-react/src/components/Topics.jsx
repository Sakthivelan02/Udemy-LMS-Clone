import { topics } from "../data/courses.js";

export default function Topics() {
  return (
    <section className="topics">
      <h2 className="topics_title">Topics Recommended for You</h2>

      <div className="topics_container">
        {topics.map((topic) => (
          <p key={topic}>{topic}</p>
        ))}
      </div>
    </section>
  );
}

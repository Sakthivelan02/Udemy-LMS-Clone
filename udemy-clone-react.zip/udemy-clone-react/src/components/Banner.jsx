export default function Banner() {
  return (
    <section className="sale-images">
      <img src="/images/1.jpg" alt="Udemy Sale Banner" />

      <div className="sale-offer">
        <h2>Get 50% Off on All Courses!</h2>
        <p>Limited time offer. Enroll now and save big.</p>
      </div>
    </section>
  );
}

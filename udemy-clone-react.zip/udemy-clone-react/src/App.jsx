import Navbar from "./components/Navbar.jsx";
import Categories from "./components/Categories.jsx";
import Banner from "./components/Banner.jsx";
import Recommended from "./components/Recommended.jsx";
import Topics from "./components/Topics.jsx";
import Popular from "./components/Popular.jsx";
import Footer from "./components/Footer.jsx";

export default function App() {
  return (
    <>
      <Navbar />
      <Categories />

      <main>
        <Banner />
        <Recommended />
        <Topics />
        <Popular />
      </main>

      <Footer />
    </>
  );
}

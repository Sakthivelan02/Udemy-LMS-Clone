# Udemy Clone — React version

This is your original HTML/CSS Udemy-clone project rebuilt as a React app
(using [Vite](https://vitejs.dev/)), with the exact same design and styling —
just split into reusable components and data-driven course lists instead of
repeated hand-written HTML blocks.

## Project structure

```
udemy-clone-react/
├── index.html              # Vite entry HTML (loads src/main.jsx)
├── package.json
├── vite.config.js
├── public/
│   └── images/              # 1.jpg ... 5.jpg (same images as the original)
└── src/
    ├── main.jsx              # React entry point
    ├── App.jsx                # Assembles all sections
    ├── index.css              # Same stylesheet as the original style.css
    ├── data/
    │   └── courses.js          # Course/category/topic data (edit this to add courses)
    └── components/
        ├── Navbar.jsx
        ├── Categories.jsx
        ├── Banner.jsx
        ├── CourseCard.jsx       # Reusable card used by Recommended & Popular
        ├── Recommended.jsx
        ├── Topics.jsx
        ├── Popular.jsx
        └── Footer.jsx
```

## How to run it

You'll need [Node.js](https://nodejs.org/) (v18+) installed.

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev
```

Then open the URL it prints (usually `http://localhost:5173`).

To build a production bundle:

```bash
npm run build
npm run preview   # preview the production build locally
```

## What changed vs. the original HTML/CSS version

- **Same look, same CSS** — `src/index.css` is your original `style.css`
  unchanged, so the visuals are identical.
- **Componentized markup** — each section (navbar, categories, banner,
  recommended courses, topics, popular courses, footer) is now its own
  React component under `src/components/`.
- **Data-driven course cards** — instead of copy-pasting a `course-card` div
  for every course, all course info lives in `src/data/courses.js` and a
  single `<CourseCard />` component renders each one. Add a new course by
  adding an object to that array — no HTML to duplicate.
- **Small fix**: the sale banner heading now uses `<h2>` to match the
  `.sale-offer h2` rule already in the CSS (in the original HTML it was an
  `<h1>`, which that rule didn't actually target).

## Next steps you could try

- Wire the search input up to `useState` and filter the course lists as you type.
- Make "My Learning" and the cart/bell icons open real dropdowns using state
  instead of CSS `:hover`.
- Add React Router if you want separate pages (e.g. a course detail page).
